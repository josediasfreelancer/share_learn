# Info

Welcome to the generated API reference.
<?php if($showPostmanCollectionButton): ?>
[Get Postman Collection](<?php echo e(url($outputPath.'/collection.json')); ?>)
<?php endif; ?>