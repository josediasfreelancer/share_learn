<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

/**
 * @resource Criar Conteúdo
 *
 * Método geral para criar conteúdos de second screen (Quiz)
 */
class Criar_ConteudoApiController extends Controller
{
    /**
     * @hideFromAPIDocumentation
     */
    public function index()
    {
        //
    }

    /**
     * @hideFromAPIDocumentation
     */
    public function create()
    {
        //
    }

    /**
     * @hideFromAPIDocumentation
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * @hideFromAPIDocumentation
     */
    public function show($id)
    {
        //
    }

    /**
     * @hideFromAPIDocumentation
     */
    public function edit($id)
    {
        //
    }

    /**
     * @hideFromAPIDocumentation
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * @hideFromAPIDocumentation
     */
    public function destroy($id)
    {
        //
    }
}
