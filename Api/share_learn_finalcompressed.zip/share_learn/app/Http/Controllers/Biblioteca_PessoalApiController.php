<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
/**
 * @resource Biblioteca Pessoal
 *
 * Método geral para listar as aplicações do meu perfil
 */
class Biblioteca_PessoalApiController extends Controller
{
    /**
     * @hideFromAPIDocumentation
     */
    public function index()
    {
        //
    }

    /**
     * @hideFromAPIDocumentation
     */
    public function create()
    {
        //
    }

    /**
     * @hideFromAPIDocumentation
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * @hideFromAPIDocumentation
     */
    public function show($id)
    {
        //
    }

    /**
     * @hideFromAPIDocumentation
     */
    public function edit($id)
    {
        //
    }

    /**
     * @hideFromAPIDocumentation
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * @hideFromAPIDocumentation
     */
    public function destroy($id)
    {
        //
    }
}
