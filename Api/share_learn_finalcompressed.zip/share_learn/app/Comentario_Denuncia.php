<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comentario_Denuncia extends Model
{
    //
}
